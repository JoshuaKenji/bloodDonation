<?php
@include "config.php";

if (isset($_POST["submit"])){
  // -The attribute in sql-||-the attribute from the php/html-
  $Full_Name = mysqli_real_escape_string($conn, $_POST["Full_Name"]);
  $Username = mysqli_real_escape_string($conn, $_POST["Username"]);
  $IC_No = mysqli_real_escape_string($conn, $_POST["IC_No"]);
  $Password = md5($_POST["Password"]);
  $Confirm_Password = md5($_POST["Confirm_Password"]);
  $Birthday = $_POST['Birthday']; //not sure
  $Past_Medical_History = mysqli_real_escape_string($conn, $_POST["Past_Medical_History"]);
  $Gender = $_POST["Gender"];
  $State = $_POST["State"];
  $Blood_Type = $_POST["Blood_Type"];
  $User_Type = $_POST["User_Type"];

  $select = " SELECT * FROM `user_form` WHERE Username = '$Username' && Password = '$Password' ";

  $result = mysqli_query($conn, $select);

  if(mysqli_num_rows($result) > 0){

    $error[] = "Username already exist!";

  }
  else{

    if($Password != $Confirm_Password){
      $error[] = "password not matched!";
    }else{
      $insert = "INSERT INTO `user_form`(Full_Name, Username, IC_NO, Birthday, Password, Past_Medical_History, Gender, State, Blood_Type, User_Type) VALUES('$Full_Name', '$Username', '$IC_No', '$Birthday', '$Password', '$Past_Medical_History', '$Gender', '$State', '$Blood_Type', '$User_Type')";
      
      mysqli_query($conn, $insert);
      header('location:../LoginPage/login_page.php');
    }
  }
};
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="SignUp_style.css">
    <title>Read Heart - Sign up</title>
</head>

<body>

  <div class="top">
    <button class="cancel"><a href="../LoginPage/login_page.php">CANCEL</a></button>
  </div>
  
  <div class="signup-box">
  <!-- <div class="signup-box" action="" method="post"> -->
      <h1>Sign up</h1>
      <h4>Create an account to join us!</h4>
      <!-- <form class="labels_class" method="post"> -->
      <form class="labels_class" action="" method="post">
        <?php
        if(isset($error)){
          foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
          };
        };
        ?>
          <label>Full name</label>
          <input type="text" required placeholder="" name="Full_Name">

          <label>Username</label>
          <input type="text" required placeholder="" name="Username">

          <label>IC No.</label>
          <input type="text" required placeholder="" name="IC_No">

          <label for="birthday">Date of Birth:</label>
          <input required type="date" id="birthday" name="Birthday">

          <label>Password</label>
          <input required type="password" name="Password">

          <label>Confirm Password</label>
          <input required type="password" name="Confirm_Password">

          <label>Past Medical History</label>
          <input type="text" placeholder="" name="Past_Medical_History">

          <h2>Gender</h2>
          <!--surround the select box with a "custom-select" DIV element. Remember to set the width:-->
          <div class="drop_down">
            <select required id="Gender" name="Gender">
              <option value="0" hidden>Select Your Gender:</option>
              <option value="1">Male</option>
              <option value="2">Female</option>
            </select>
          </div>

          <h2>State</h2>
          <!--surround the select box with a "custom-select" DIV element. Remember to set the width:-->
          <div class="drop_down">
            <select required id="state" name="State">
              <option value="0" hidden>Select Your State:</option>
              <option value="1">Johor</option>
              <option value="2">Kedah</option>
              <option value="3">Kelantan</option> 
              <option value="4">Malacca</option>
              <option value="5">Negeri Sembilan</option>
              <option value="6">Pahang</option>
              <option value="7">Penang</option>
              <option value="8">Perak</option>
              <option value="9">Perlis</option>
              <option value="10">Selangor</option>
              <option value="11">Terengganu</option>
              <option value="12">Kuala Lumpur</option>
              <option value="13">Putra Jaya</option>
            </select>

          <h2>Blood Type</h2>
          <!--surround the select box with a "custom-select" DIV element. Remember to set the width:-->
          <div class="drop_down">
            <select required id="Blood_type" name="Blood_Type">
              <option value="0" hidden>Select Blood group:</option>
              <!-- <option value="1">A</option> -->
              <option value="2">A +</option>
              <option value="3">A -</option>
              <!-- <option value="4">B</option> -->
              <option value="5">B +</option>
              <option value="6">B -</option>
              <!-- <option value="7">O</option> -->
              <option value="8">O +</option>
              <option value="9">O -</option>
              <!-- <option value="10">AB</option> -->
              <option value="11">AB +</option>
              <option value="12">AB -</option>
            </select>

          <h2>Register as</h2>
          <!--surround the select box with a "custom-select" DIV element. Remember to set the width:-->
          <div class="drop_down">
            <select required id="User_Type" name="User_Type">
              <option value="0" hidden>Select User Type:</option>
              <option value="1">Donor</option>
              <option value="2">Recipient</option>
            </select>
          </div>

        <input type="submit" name="submit" value="Register"> 

      </form>
  </div>
</body>
</html>