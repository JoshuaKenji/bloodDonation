<?php

//user safety login

session_start();

if(!isset($_SESSION['Recipient_Username'])){
  header("location:../../../LoginPage/login_page.php");
}

?>

<!-- ------------------ -->

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Consent</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="consent.css">
  </head>
  <body>
    <header class="header">
      <div class="header-title">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL-RP.php">
        <div class="log-out-text">BACK</div>
        <img class="log-out-icon" src="../../../icons/logout-icon.png">
        </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
          <div class="top-bar-title">Blood Donation Consent</div>
      </nav>
      <div class="consent-section">
        <div class="consent-box">
          <div class="consent-section-title-bar">
            <div class="consent-form-title">Blood Donation - Consent Form</div>
          </div>
          
          <div class="recipient-section">
            <div class="recipient-section-title">Blood Recipient Information</div>
            <div class="sub-section">
              <div class="sub-title">Recipient Name: </div>
              <div class="recipient-name">Anonymous</div>
            </div>
          </div>
          
          <div class="donor-section">
            <div class="donor-section-title">Blood Donor Information</div>
            <div class="sub-section">
              <div class="sub-title">Donor Name: </div>
              <div class="donor-name">Muhammad Ali</div>
            </div>
            <div class="sub-section">
              <div class="sub-title">Blood Type:</div>
              <div class="blood-type">O</div>
            </div>
          </div>
          
          <div class="schedule-section"> 
            <div class="sub-section">
              <div class="sub-title">Location:</div>
              <div class="location">Malaysia Court Medical Centre</div>
            </div>
            <div class="sub-section">
              <div class="sub-title">Date:</div>
              <div class="date">6 August 2022</div>
            </div>
          </div>
          
          <div class="button-section">
            <button class="accept-button">Accept</button>
            <button class="reject-button">Reject</button>
          </div>
          
        </div>
      </div>
    </div>
  </body>
</html>