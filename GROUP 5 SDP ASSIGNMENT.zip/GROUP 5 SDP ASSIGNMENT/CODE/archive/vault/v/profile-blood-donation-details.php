<?php

@include "config.php";

session_start();

if(!isset($_SESSION['Donor_Username'])){
    header("location:../../../LoginPage/login_page.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Profile - BDD</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="profile-blood-donation-details.css">
  </head>
  <body>
    <header class="header">
      <div class="header-title">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../../icons/logout-icon.png">
        </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
          <div class="personal-information-panel"><a href="profile-personal-information.php">Personal Information</a></div>
          <div class="blood-donation-details-panel"><a>Blood Donation History</a></div>
      </nav>
      <div class="blood-donation-details-section">
        <!-- <img class="background-picture" src="../../../ImageAssets/blood-donation-background.jpg"> -->
        <div class="notification">***The system will only display 5 latest blood donation done***</div>
        <div class="blood-donation-details-table">
          <div class="blood-donation-details-title">Location Name</div>
          <div class="blood-donation-details-title">Location Type</div>
          <div class="blood-donation-details-title">Address</div>
          <div class="blood-donation-details-title">Blood Donation Date</div>
          <div class="blood-donation-details-title">Time</div>
          <!--First row-->
          <div class="location-name">Malaysia Court Medical Centre</div>
          <div class="location-type">Hospital</div>
          <div class="address">39, Jalan Kia Peng, Kuala Lumpur, 50450 Kuala Lumpur</div>
          <div class="blood-donation-date">6 August 2022</div>
          <div class="time">2.00 PM</div>
          <!--Second row-->
          <div class="location-name">Malaysia Court Medical Centre</div>
          <div class="location-type">Hospital</div>
          <div class="address">39, Jalan Kia Peng, Kuala Lumpur, 50450 Kuala Lumpur</div>
          <div class="blood-donation-date">6 August 2022</div>
          <div class="time">2.00 PM</div>
          <!--Third row-->
          <div class="location-name">Malaysia Court Medical Centre</div>
          <div class="location-type">Hospital</div>
          <div class="address">39, Jalan Kia Peng, Kuala Lumpur, 50450 Kuala Lumpur</div>
          <div class="blood-donation-date">6 August 2022</div>
          <div class="time">2.00 PM</div>
          <!--Forth row-->
          <div class="location-name">Malaysia Court Medical Centre</div>
          <div class="location-type">Hospital</div>
          <div class="address">39, Jalan Kia Peng, Kuala Lumpur, 50450 Kuala Lumpur</div>
          <div class="blood-donation-date">6 August 2022</div>
          <div class="time">2.00 PM</div>
          <!--Fifth row-->
          <div class="location-name">Malaysia Court Medical Centre</div>
          <div class="location-type">Hospital</div>
          <div class="address">39, Jalan Kia Peng, Kuala Lumpur, 50450 Kuala Lumpur</div>
          <div class="blood-donation-date">6 August 2022</div>
          <div class="time">2.00 PM</div>
        </div>
      </div>
    </div>
  </body>
</html>