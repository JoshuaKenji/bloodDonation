<?php
@include "config.php";

session_start();

if (isset($_POST["submit"])){

  // // -The attribute in sql-||-the attribute from the php/html-
  // $Full_Name = mysqli_real_escape_string($conn, $_POST["Full_Name"]);
  $Username = mysqli_real_escape_string($conn, $_POST["Username"]);
  // $Username = $_POST["Username"];
  // $IC_No = mysqli_real_escape_string($conn, $_POST["IC_No"]);
  // // $Password = mysqli_real_escape_string($conn, $_POST["Password"]);
  $Password = md5($_POST["Password"]);
  // $Password = $_POST["Password"];
  // $Confirm_Password = md5($_POST["Confirm_Password"]);
  // $Birthday = $_POST['Birthday']; //not sure
  // $Past_Medical_History = mysqli_real_escape_string($conn, $_POST["Past_Medical_History"]);
  // $Gender = $_POST["Gender"];
  // $State = $_POST["State"];
  // $Blood_Type = $_POST["Blood_Type"];
  // $User_Type = $_POST["User_Type"];

  $select = " SELECT * FROM `user_form` WHERE Username = '$Username' && Password = '$Password' ";

  $result = mysqli_query($conn, $select);

  if(mysqli_num_rows($result) > 0){

    $row = mysqli_fetch_array($result);

    if($row['User_Type'] == "Donor"){

      $_SESSION['Donor_Username'] = $row["Username"];
      //primary key
      $_SESSION['Donor_UserID'] = $row["User_ID"];
      //--
      header('location:../Homepage_AL/DONOR/home_page_AL.php');
      // $_SESSION['Donor_Full_Name'] = $row["Full_Name"];
      // header('location:../Homepage_AL/DONOR/home_page_AL.php');

    }elseif($row['User_Type'] == "Recipient"){

      $_SESSION['Recipient_Username'] = $row["Username"];
      //primary key
      $_SESSION['Recipient_UserID'] = $row["User_ID"];
      //--
      // $_SESSION['Recipient_FN'] = $row["Full_Name"];
      header('location:../Homepage_AL/RECIPIENT/home_page_AL-RP.php');
    }
    
    
  }else{
    $error[] = "incorrect username or password!";
  }

};
?>

<!-- --------------------------------------------------------------------- -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Read Heart - Login Page</title>
        <link rel="stylesheet" href="login_page_style.css">
    </head>

    <body>

      <div class="top">
        <button class="back"><a href="../home_page.html">BACK</a></button>
      </div>

      <div class="center">
        <h1>Login</h1>
        <form action="" method="post">

        <!-- php connection -->
        <?php
        if(isset($error)){
          foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
          };
        };
        ?>

          <div class="txt_field">
            <input type="text" name="Username" required placeholder="">
            <span></span>
            <label>Username</label>
          </div>
          <div class="txt_field">
            <input type="password" name="Password" required placeholder="">
            <span></span>
            <label>Password</label>
          </div>

          <input class="button" name="submit" type="submit" value="Login">
          
          <div class="signup_link">
            No Accounts? <a href="../SignUpPage/SignUp.php">Sign Up?</a>
          </div>
        </form>
      </div>

    </body>
</html>