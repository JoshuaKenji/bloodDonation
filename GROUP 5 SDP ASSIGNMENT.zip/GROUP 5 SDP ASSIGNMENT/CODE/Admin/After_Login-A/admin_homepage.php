<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../login_page-A");
}

?>

<!-- ------------------ -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Admin's Home Page</title>
        <link rel="stylesheet" href="admin_homepage.css"/>
    </head>
  
    <body>

        <div class="main" id="home">

            <div class="navbar">
                <div class="icon">
                    <h2 class="logo"><a href="#" style="text-shadow: 0.5px 0.5px 1px #000000;">Red Heart</a></h2>
                </div>

                <div class="menu">                    
                    <ul>
                        <li><a href="doctorinfo/doctor.php">Doctor Information</a></li>
                        <li><a href="doctorinfo/hospital.php">Hospital Information</a></li>
                        <!-- <li><a href="#">Edit Doctor Information</a></li> -->
                        <li><a href="cruds_hospital/read_h.php">Edit Hospital Information</a></li>
                    </ul>
                </div>
                <div class="login-user-section">
                <div><a class="login-user-tab" href="#">
                    <div class="login-username"></div>
                    <img class="drop-down-icon" src="../../icons/down-arrow-button.png"></a>
                </div>
                <div class="login-sub-menu">
                    <div class="sign-out-tab"><a href="../../SignOut.php">Sign Out</a></div>
                </div>
                </div>
            </div>

            <div class="home">

                <h1>Hello <span style="color:yellowgreen;text-shadow: 0.5px 0.5px 1px #000000;">ADMIN!</span></h1>

                <p class="par1">Hello our lovely Admin!<br> We appreciate the voluntary service you brought to us. We hope that your service<br>brings benefit to West Malaysia and you can enjoy your experience with us.<br>Once again, thank you for supporting!</p>

            </div>
        </div>

  </body>
</html>
