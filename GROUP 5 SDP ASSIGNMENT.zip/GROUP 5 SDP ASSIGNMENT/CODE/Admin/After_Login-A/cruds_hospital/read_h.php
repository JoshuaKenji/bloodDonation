<HTML>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Location</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="style.css" >
</head>


<body style ="margin:50px;" >
    <?php
    include('db.php');
    $query="SELECT * FROM hospital;";
    $result= mysqli_query($conn, $query);

    //user safety login
    if(!isset($_SESSION['admin_username'])){
        header("location:../../login_page-A");
    }

    ?>
    <div class="container-my-5">
        <h1>Location Management</h1>
        <a class="btn btn-primary" href="create1.php" role="button" style="margin-top:15px;margin-bottom:20px;">New Location</a>
        <br>
        <!-- <form action="create.php" method='post'> -->
        <table class='table'>
            <tr>
                <th>Hospital ID</th>
                <th>Location name</th>
                <th>Location type</th>
                <th>Address</th>
                <th>State</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            <?php
                $i=0;
                while($row=mysqli_fetch_array($result))
                {
            ?>
                <tr>
                    <td><?php echo $row['H_id'] ?></td>
                    <td><?php echo $row['location_name'] ?></td>
                    <td><?php echo $row['location_type'] ?></td>
                    <td><?php echo $row['address'] ?></td>
                    <td><?php echo $row['state'] ?></td>
                    <td><a href="update1.php?H_id=<?php echo $row["H_id"]; ?>">Update</a></td>
                    <td><a href="delete1.php?H_id=<?php echo $row["H_id"]; ?>"><span style="color:red"><u><i>Delete</i></u></span></a></td>
                </tr>
            <?php
            $i++;
                }
            ?>
        </table>
        <!-- <div class="top" role="button" style="margin-top:10px;">
            <a class="btn btn-primary" href="../admin_homepage.php">BACK</a>
        </div> -->

        <div class="col-sm-3-d-grid" role="button" >
            <a class="btn btn-outline-primary" href="../admin_homepage.php">BACK</a>
        </div>
    </div>
</body>
</HTML>