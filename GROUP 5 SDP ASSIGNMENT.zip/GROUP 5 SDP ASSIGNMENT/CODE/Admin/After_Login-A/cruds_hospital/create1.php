<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../../login_page-A");
}

?>

<!-- ------------------ -->

<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "user_db";

//create connection
$connection = new mysqli($servername, $username, $password, $db);

$location_name = "";
$location_type = "";
$address = "";
$state = "";

$errorMessage = "";
$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $location_name = $_POST["location_name"];
    $location_type = $_POST["location_type"];
    $address = $_POST["address"];
    $state = $_POST["state"];

    do {
        if (empty($location_name) || empty($location_type) || empty($address) || empty($state)) {
            $errorMessage = "All fields are required";
            break;
        }

        //add new schedule to the database
        $sql = "INSERT INTO hospital ( location_name, location_type, address, state)" .
            "VALUES ('$location_name','$location_type','$address', '$state')";
        $result = $connection->query($sql);

        if (!$result) {
            $errorMessage = " Invalid query:" . $connection->error;
            break;
        }

        $location_name = "";
        $location_type = "";
        $address = "";
        $state = "";


        $successMessage = "Schedule created successfully";

        header("Location: read_h.php");
        exit;
    } while (false);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - New Info</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css" >
</head>

<body>
    <div class="container my-5">
        <h1>New Location Information</h1>

        <?php
        if (!empty($errorMessage)) {
            echo " 
            <div class='alert alert-warning alert-dismissable fade show' role='alert'>
                <strong>$errorMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>
            </div>
            ";
        }
        ?>

        <form method="post">
            <div class="row mb-3" style="margin-top:20px;">
                <label class="col-sm-6 col-form-label">Location Name</label>
                <div class="col-sm-6" style="margin-left:0.1px;margin-bottom:5px"> 
                    <input type="text" class="form-control" name="location_name" value="<?php echo $location_name; ?>">
                </div>
                <label class="col-sm-6 col-form-label">Location Type</label>
                <div class="col-sm-6" style="margin-left:0.1px;margin-bottom:5px">
                    <input type="text" class="form-control" name="location_type" value="<?php echo $location_type; ?>">
                </div>
                <label class="col-sm-6 col-form-label">Address</label>
                <div class="col-sm-6" style="margin-left:0.1px;margin-bottom:5px">
                        <input type="text" class="form-control" name="address" value="<?php echo $address; ?>">
                </div>
                <label class="col-sm-6 col-form-label">State</label>
                <div class="col-sm-6" style="margin-left:0.1px;margin-bottom:5px">
                    <input type="text" class="form-control" name="state" value="<?php echo $state; ?>">
                </div>
            </div>
                
            <div>
                            <?php
                            if (!empty($successMessage)) {
                                echo " 
                <div class= 'row mb-3'>
                <div class='offset-sm-3 col-sm-6'>
                <div class='alert alert-warning alert-dismissable fade show' role='alert'>
                    <strong>$successMessage</strong>
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='close'></button>
                </div>
                </div>
                </div>
                ";
                            }

                            ?>
                <!-- 
                <div>
                    <div class="offset-sm-3 col-sm-3 d-grid">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                    <div class="col-sm-3 d-grid">
                        <a class="btn btn-outline-primary" href="read_h.php" role="button">Cancel</a>
                    </div>
                </div> -->

                <table class ="col-sm-3-d-grid">
                    <tr>
                        <div class="offset-sm-3 col-sm-3 d-grid" style="margin-top:20px;margin-left: 0px">
                            <input type="submit" class="btn btn-primary" name="update" value="Save"/>
                        </div>

                        <div class="col-sm-3-d-grid" style="margin-top:15px;margin-left: 0px">
                            <a class="btn btn-outline-primary" href="read_h.php" role="button">Cancel</a> 
                        </div>
                    </tr>
                </table>

            </div>
        </form>
    </div>
</body>

</html>