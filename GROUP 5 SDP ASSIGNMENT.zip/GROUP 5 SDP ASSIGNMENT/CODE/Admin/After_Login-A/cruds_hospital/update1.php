<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Update Info</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css" >
</head>

<body>
    <div class="container my-5">
        <h2>Update Hospital Information</h2>
        <form method="post">
            <div class ="row mb-3">
                <label class="col-sm-6 col-form-label">Hospital ID</label>
                <div class = "col-sm-6" style="margin-left:0.1px">
                    <input type="text" class="form-control" name= "H_id" value="" placeholder="Please Type Hospital ID" >
                </div>
                <br>
                <br>
                <label class="col-sm-6 col-form-label">Location name</label>
                <div class = "col-sm-6" style="margin-left:0.1px">
                    <input type="text" class="form-control" name= "location_name" value="" placeholder="Please Type Location name">
                </div>
                <br>
                <br>
                <label class="col-sm-6 col-form-label">Location type</label>
                <div class = "col-sm-6" style="margin-left:0.1px">
                    <input type="text" class="form-control" name= "location_type" value="" placeholder="Please Type Location type">
                </div>
                <br>
                <br>
                <label class="col-sm-6 col-form-label">Address</label>
                <div class = "col-sm-6" style="margin-left:0.1px">
                    <input type="text" class="form-control" name= "address" value="" placeholder="Please Type Address">
                </div>
                <br>
                <br>
                <label class="col-sm-6 col-form-label">State</label>
                <div class = "col-sm-6" style="margin-left:0.1px">
                    <input type="text" class="form-control" name= "state" value="" placeholder="Please Type State">
                </div>
            </div>

            <table class ="col-sm-3 d-grid">
                <tr>
                    <div class="offset-sm-3 col-sm-3 d-grid" style="margin-top:15px;margin-left: 0px">
                        <input type="submit" class="btn btn-primary" name="update" value="Save"/>
                    </div>

                    <div class="col-sm-3-d-grid" style="margin-top:15px;margin-left: 0px">
                        <a class="btn btn-outline-primary" href="read_h.php" role="button">Cancel</a> 
                    </div>
                </tr>
            </table>


            <?php
                include('db.php');
                //user safety login
                if(!isset($_SESSION['admin_username'])){
                    header("location:../../login_page-A");
                }
                if(isset($_POST['update']))
                {
                    $H_id=$_POST['H_id'];
                    $query="UPDATE hospital SET location_name='$_POST[location_name]', location_type='$_POST[location_type]',address='$_POST[address]', state='$_POST[state]' WHERE H_id='$_POST[H_id]'";
                    $query_run= mysqli_query($conn,$query);
                    if($query_run)
                    {
                    echo '<script type="text/javascript">alert("Data Updated")</script>';
                    }
                    else
                    {
                    echo'<script type="text/javascript">alert("Data Not Updated")</script>';                
                    }
                    header("Location: read_h.php");
                }
            ?>


        </form>
    </div>   
</body>
