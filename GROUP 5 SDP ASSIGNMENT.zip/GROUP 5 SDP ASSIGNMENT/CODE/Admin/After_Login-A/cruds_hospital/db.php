<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../../login_page-A");
}

?>

<!-- ------------------ -->

<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $db = "user_db";

    $conn = mysqli_connect($hostname, $username, $password, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>