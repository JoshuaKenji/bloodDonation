<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../../login_page-A");
}

?>

<!-- ------------------ -->

<?php
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $db = "user_db";

  $conn = mysqli_connect($hostname, $username, $password, $db);

  $sql = "DELETE FROM hospital WHERE H_id='" . $_GET["H_id"] . "'";
  if (mysqli_query($conn, $sql)) {
      echo "<script LANGUAGE='JavaScript'>
      window.alert('Delete Success');
      window.location.href='read_h.php';
      </script>";
  } else {
      echo "Error deleting record: " . mysqli_error($conn);
  }
  mysqli_close($conn);
?>
