<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../../login_page-A");
}

?>

<!-- ---- -->



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospitals Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css" >
</head>

<body style="margin:50px;">
    <div class="container my-5">
        <h1>Hospitals Information</h1>
        <div class="top">
            <button class="back"><a href="../admin_homepage.php">BACK</a></button>
        </div>
        
        <table class=table>
            <thead>
                <tr>
                    <th scope="col">H_id</th>
                    <th scope="col">Hospital Name</th>
                    <th scope="col">Location Type</th>
                    <th scope="col">Address</th>
                    <th scope="col">State</th>
                </tr>
            </thead>
            <tbody>

                <?php
                include('connect.php');
                // select query
                $sql = "SELECT * FROM `hospital`";
                $result = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $H_id = $row['H_id'];
                    $hospital_name = $row['location_name'];
                    $location_type = $row['location_type'];
                    $address = $row['address'];
                    $state = $row['state'];
                    echo '<tr>
             <th scope ="row">' . $H_id . '</th>
             <td>' . $hospital_name . '</td>
             <td>' . $location_type . '</td>
             <td>' . $address . '</td>
             <td>' . $state . '</td>
                </tr>';
            }

             ?>
            