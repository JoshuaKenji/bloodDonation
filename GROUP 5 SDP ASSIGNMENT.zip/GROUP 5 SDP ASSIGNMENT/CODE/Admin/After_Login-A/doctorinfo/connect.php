<?php
$con=mysqli_connect('localhost','root','','user_db');
if(!$con){
    die(mysqli_error("Error" +$con));
}

?>