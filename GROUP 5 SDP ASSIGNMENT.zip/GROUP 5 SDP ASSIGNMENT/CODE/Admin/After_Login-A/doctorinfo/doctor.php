<?php

//user safety login

session_start();

if(!isset($_SESSION['admin_username'])){
    header("location:../../login_page-A");
}

?>

<!-- ---- -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Information</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css" >
</head>

<body style="margin:50px;">
    <div class="container my-5">
        <h1>Doctor Information</h1>
        <div class="top" style="margin-top:20px;margin-bottom:20px">
            <button class="back"><a href="../admin_homepage.php">BACK</a></button>
        </div>
        
        <table class=table>
            <thead>
                <tr>
                    <th scope="col">D_id</th>
                    <th scope="col">Doctor name</th>
                    <th scope="col">Username</th>
                    <th scope="col">Specialism</th>
                    <th scope="col">Certification</th>
                </tr>
            </thead>
            <tbody>

                <?php
                include('connect.php');
                // select query
                $sql = "SELECT * FROM `doctor`";
                $result = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_assoc($result)) {
                    $D_id = $row['D_id'];
                    $doctor_name = $row['doctor_name'];
                    $username = $row['Username'];
                    $specialism = $row['specialism'];
                    $certification = $row['certification'];
                    echo '<tr>
             <th scope ="row">' . $D_id . '</th>
             <td>' . $doctor_name . '</td>
             <td>' . $username . '</td>
             <td>' . $specialism . '</td>
             <td>' . $certification . '</td>
                </tr>';
            }

             ?>
            