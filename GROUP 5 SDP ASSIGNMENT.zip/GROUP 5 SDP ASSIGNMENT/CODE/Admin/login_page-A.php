<?php
@include "../../config.php";

session_start();

if (isset($_POST["submit"])){

  $username = $_POST['Username'];
  $password = $_POST['Password'];

  if($username == "admin" && $password == "admin"){
    $_SESSION["admin_username"] = 'admin';
    header("location:After_Login-A/admin_homepage.php");
    
  }else{
    // echo '<script type="text/javascript"> alert("Register Unsuccessful")</script>';
    $error[] = "incorrect username or password!";
  }

};
?>

<!-- --------------------------------------------------------------------- -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Read Heart - Admin's Login Page</title>
        <link rel="stylesheet" href="login_page_style.css">
    </head>

    <body>

      <div class="top">
        <button class="back"><a href="../home_page.html">BACK</a></button>
      </div>

      <div class="center">
        <h1>Admin's Login</h1>
        <form action="" method="post">

        <!-- php connection -->
        <?php
        if(isset($error)){
          foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
          };
        };
        ?>

          <div class="txt_field">
            <input type="text" name="Username" required>
            <!-- <input type="text" name="Username" required placeholder=""> -->
            <span></span>
            <label>Username</label>
          </div>
          <div class="txt_field">
            <input type="password" name="Password" required>
            <span></span>
            <label>Password</label>
          </div>

          <input class="button" name="submit" type="submit" value="Login">

        </form>
      </div>

    </body>
</html>