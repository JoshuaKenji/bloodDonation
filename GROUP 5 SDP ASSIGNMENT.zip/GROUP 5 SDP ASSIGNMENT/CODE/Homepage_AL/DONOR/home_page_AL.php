<?php

@include "config.php";

session_start();

//verify users
if(!isset($_SESSION['Donor_Username'])){
    header("location:../../LoginPage/login_page.php");
}

?>
 
<!DOCTYPE html>
<html lang="en">

  <head>
    <title>Donor's Booking Page</title>
    <link rel="stylesheet" href="home_page_AL_style.css"/>
  </head>
  
  <body>
    <div class="main" id="home">

        <div class="navbar">
            <div class="icon">
                <h2 class="logo"><a href="home_page_AL.php" style="color: #DC143C">Red Heart</a></h2>
            </div>

            <div class="menu">                    
                <ul>
                    <li><a href="home_page_AL.php#home">HOME</a></li>
                    <!-- <li><a href="home_page_AL.html#about_us">ABOUT US</a></li> -->
                    <li><a href="home_page_AL.php#contact">CONTACT</a></li>
                    <li><a href="BloodDonation/blood-donation-schedule.php">BLOOD DONATION</a></li>
                    <li><a href="booking/blood-donation-booking.php">BOOK</a></li>
                </ul>
            </div>
            <div class="login-user-section">
              <div><a class="login-user-tab" href="#">
                <div class="login-username"><?php echo $_SESSION['Donor_Username'] ?></div>
                <img class="drop-down-icon" src="../../icons/down-arrow-button.png"></a>
              </div>
              <div class="login-sub-menu">
                <div class="profile-tab"><a href="SubMenu/profile-personal-information.php" >Profile</a></div>
                <!-- <div class="consent-tab"><a href="SubMenu/consent.html">Consent</a></div> -->
                <div class="sign-out-tab"><a href="../../SignOut.php">Sign Out</a></div>
              </div>
            </div>
            
        </div>

        <div class="home">

            <h1>Hello <span style="color:#ff0000; text-transform:uppercase;"><?php echo $_SESSION['Donor_Username'] ?></span></h1>

            <p class="par1">Thank you for joining us.<br>Again, we are Red Heart Donations, a volunteer-based organization that<br>helps the blood donation around West Malaysia. We appreciate all the<br>support that we get from all of the Donors, voluntary Doctors and Staff.<br>Once again, thank you for supporting!</p>
        
            <!-- <button class="ju"><a href="LoginPage/login_page.html">JOIN US</a></button> -->

        </div>
    </div>

    <div class="white_break"></div>

    <div class="main3" id="contact">
        <div class="contact">

            <br><br>

            <h1>Contact Us</h1>
            <p class="par3">
            <span style="font-weight: bold; color: #ffff5d; text-shadow: 0.5px 0.5px 1px #000000;">CONTACT NUMBER &nbsp; </span> +60XX-XXX-XXXX
            <br>
            <span style="font-weight: bold; color: #ffff5d; text-shadow: 0.5px 0.5px 1px #000000;">EMAIL SUPPORT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span> RedHeartService@support.rh.my
            <br>
            <span style="font-weight: bold; color: #ffff5d; text-shadow: 0.5px 0.5px 1px #000000;">HQ ADDRESS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> Jalan Lorem, Taman Park Zero, 62025 Kuala Lumpur, Malaysia
            </p>  
        </div>
    </div>

    <div class="white_break"></div>

  </body>
</html>
