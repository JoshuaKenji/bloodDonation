function selectState(){ 
  var x = document.getElementById("state").value;

  $.ajax({
    url: "schedule-filter-location.php",
    method: "POST",
    data:{
      id : x
    },
    success: function(data){
      $("#schedule_data").html(data);
    }
  });
}