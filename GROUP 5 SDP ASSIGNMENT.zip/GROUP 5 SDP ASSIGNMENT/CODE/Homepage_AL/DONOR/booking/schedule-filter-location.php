<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = mysqli_connect("localhost", "root", "", "user_db");

$selected_state = $_POST['id'];
$selected_state = trim($selected_state);
if ($selected_state != "all"){
  $sql = "SELECT location_schedule.schedule_id, location_schedule.location_name, hospital.location_type, 
  hospital.state,location_schedule.date, location_schedule.time 
  FROM location_schedule INNER JOIN hospital
  ON location_schedule.location_name = hospital.location_name
  WHERE state='{$selected_state}'
  ORDER BY location_schedule.date ASC";
  $result = $conn->query($sql);
  while ($rows = $result->fetch_assoc()){
  ?>  <tr>
        <td><?php echo $rows['location_name']; ?></td>
        <td><?php echo $rows['location_type']; ?></td>
        <td><?php echo $rows['state']; ?></td>
        <td><?php echo $rows['date']; ?></td>
        <td><?php echo $rows['time']; ?></td>
        <td>
          <a id="book" href="book.php?id=<?php echo $rows["schedule_id"] ?>">BOOK</a>
        </td>
      </tr>
  <?php 
  }
}else if ($selected_state = "all"){
  $sql = "SELECT location_schedule.schedule_id, location_schedule.location_name, hospital.location_type, 
  hospital.state,location_schedule.date, location_schedule.time 
  FROM location_schedule INNER JOIN hospital
  ON location_schedule.location_name = hospital.location_name
  ORDER BY location_schedule.date ASC";
  $result = $conn->query($sql);
  while ($rows = $result->fetch_assoc()){
  ?>  <tr>
        <td><?php echo $rows['location_name']; ?></td>
        <td><?php echo $rows['location_type']; ?></td>
        <td><?php echo $rows['state']; ?></td>
        <td><?php echo $rows['date']; ?></td>
        <td><?php echo $rows['time']; ?></td>
        <td>
          <a id="book" href="book.php?id=<?php echo $rows["schedule_id"] ?>">BOOK</a>
        </td>
      </tr>
  <?php
  }
} ?>