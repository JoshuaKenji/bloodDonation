<?php
@include "../config.php";

session_start();

if(!isset($_SESSION['Donor_Username'])){
    header("location:../../../LoginPage/login_page.php");
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$donor_name = $_SESSION['Donor_Username'];
$id = $_GET["id"];

$sql = "SELECT User_ID from user_form WHERE Username='$donor_name'";
$result = $conn->query($sql);
if ($result -> num_rows >0){
  while($row = $result -> fetch_assoc()){
    $userID = $row["User_ID"];
  }
}

$sql2 = "SELECT location_schedule.schedule_ID, location_schedule.location_name, 
hospital.location_type, location_schedule.date, location_schedule.time 
FROM location_schedule LEFT JOIN hospital 
ON location_schedule.location_name = hospital.location_name
WHERE location_schedule.schedule_ID='$id'";
$result2 = $conn->query($sql2);
if ($result2 -> num_rows >0){
  while($row2 = $result2->fetch_assoc()){
    $schedule_id = $row2["schedule_ID"];
    $location_name = $row2["location_name"];
    $location_type = $row2["location_type"];
    $date = $row2["date"];
    $time = $row2["time"];
  }
}else{
  echo "0 results";
}

$sql3 = "INSERT INTO blood_donation (user_id, schedule_id, location_name, location_type, date, time)
VALUES ('$userID','$schedule_id','$location_name','$location_type','$date','$time')";
if ($conn->query($sql3) === TRUE) {
  header("location:blood-donation-booking.php ? message=success&id=".$blood_donation_id);
} else {
  echo "Error: " . $sql3 . "<br>" . $conn->error;
}

$conn->close();//close database connection to reduce straints

?>