<?php
@include "../config.php";

//verify user

session_start();

if(!isset($_SESSION['Donor_Username'])){
    header("location:../../../LoginPage/login_page.php");
}

?>
<!DOCTYPE html>

<html>
  <head>
    <title>RED HEART - DONATION BOOKING</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript" src="blood-donation-booking.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="../SubMenu/profile-personal-information.css">
    <link rel="stylesheet" href="blood-donation-booking.css">
  </head>
  <body>
    <header class="header">
      <div class="header-profile">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../../icons/logout-icon.png">
          </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
        <div class="title-panel">BLOOD DONATION BOOKING</div>
      </nav>
      <div class="drop-down-list-panel">
        <div class="state-panel">
          <h>Select state:</h>
          <div class="state_drop_down">
            <select id="state" class="state_option" onchange="selectState()">
              <option value="all">--- Select All ---</option>
              <?php
              $state_sql = "SELECT DISTINCT state FROM hospital"; 
              $state_result = mysqli_query($conn, $state_sql);
              while ($state_rows = mysqli_fetch_array($state_result)){
              ?>
                <option value="<?php echo $state_rows['state']; ?>"><?php echo $state_rows['state']; ?></option>
              <?php
              }
              ?>
            </select>
          </div>
        </div>
      </div>
      <div class= "location-table">
        <div class= "update-info">
          <?php
          if (isset($_GET["message"])){
            if (($_GET["message"])=="success"){
              echo "* Blood Donation successfully booked";
            }
          }
          ?>
        </div>
        <div class="table-data">
          <?php
          $sql2 = "SELECT location_schedule.schedule_id, location_schedule.location_name,
          hospital.location_type, hospital.state, location_schedule.date, location_schedule.time 
          FROM location_schedule INNER JOIN hospital 
          ON location_schedule.location_name = hospital.location_name
          ORDER BY location_schedule.date ASC";
          $result2 = mysqli_query($conn,$sql2);
          ?>
          <table class="table">
            <thead>
              <th>Location Name</th>
              <th>Location Type</th>
              <th>State</th>
              <th>Date</th>
              <th>Time</th>
              <th>BOOKING</th>
            </thead>
            <tbody id="schedule_data">
              <?php
              if ($result2->num_rows > 0) {
                // output data of each row
                while($row2 = $result2->fetch_assoc()) {
              ?>
                  <tr>
                    <td><?php echo $row2["location_name"]; ?></td>
                    <td><?php echo $row2["location_type"]; ?></td>
                    <td><?php echo $row2["state"]; ?></td>
                    <td><?php echo $row2["date"]; ?></td>
                    <td><?php echo $row2["time"]; ?></td>
                    <td>
                    <a id="book" href="book.php?id=<?php echo $row2["schedule_id"] ?>">BOOK</a>
                    </td>
                  </tr>
          <?php }
              }else {
                echo "0 results";
              }
              $conn->close(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </body>
</html>