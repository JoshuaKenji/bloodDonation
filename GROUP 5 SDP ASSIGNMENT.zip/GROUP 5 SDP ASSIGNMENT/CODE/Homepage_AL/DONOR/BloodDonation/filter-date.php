<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = mysqli_connect("localhost", "root", "", "user_db");

$selected_date = $_POST['id'];
$selected_date = trim($selected_date);
if ($selected_date != "all"){
  $sql = "SELECT location_schedule.schedule_ID, location_schedule.location_name,
  hospital.location_type, hospital.state, location_schedule.date, location_schedule.time 
  FROM location_schedule INNER JOIN hospital 
  ON location_schedule.location_name = hospital.location_name 
  WHERE location_schedule.date = '{$selected_date}'";
  $result = mysqli_query($conn, $sql);
  while ($rows = mysqli_fetch_array($result)){
  ?>  <tr>
        <td><?php echo $rows["location_name"]; ?></td>
        <td><?php echo $rows["location_type"]; ?></td>
        <td><?php echo $rows["state"]; ?></td>
        <td><?php echo $rows["date"]; ?></td>
        <td><?php echo $rows["time"]; ?></td>
      </tr>
  <?php 
  }
}else{
  $sql2 = "SELECT location_schedule.schedule_ID, location_schedule.location_name,
  hospital.location_type, hospital.state, location_schedule.date, location_schedule.time 
  FROM location_schedule INNER JOIN hospital 
  ON location_schedule.location_name = hospital.location_name
  ORDER BY location_schedule.date ASC";
  $result2 = mysqli_query($conn,$sql2);
  while ($rows2 = mysqli_fetch_array($result2)){
  ?>  <tr>
        <td><?php echo $rows2["location_name"]; ?></td>
        <td><?php echo $rows2["location_type"]; ?></td>
        <td><?php echo $rows2["state"]; ?></td>
        <td><?php echo $rows2["date"]; ?></td>
        <td><?php echo $rows2["time"]; ?></td>
      </tr>
  <?php
  }
} ?>