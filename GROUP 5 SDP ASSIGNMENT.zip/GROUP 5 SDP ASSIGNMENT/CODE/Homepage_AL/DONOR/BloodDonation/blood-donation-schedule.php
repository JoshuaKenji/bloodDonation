<?php
@include "../config.php";

session_start();

if(!isset($_SESSION['Donor_Username'])){
    header("location:../../../LoginPage/login_page.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Blood Donation</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script type="text/javascript" src="blood-donation-schedule.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="profile-personal-information.css">
    <link rel="stylesheet" href="blood-donation-schedule.css">
  </head>
  <body>
    <div class="header">
      <div class="header-profile">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../../icons/logout-icon.png">
          </a>
      </div>
    </div>
    <div class="main-body">
      <nav class="top-bar">
        <div class="personal-information-panel"><a href="#">Blood Donation Schedule</a></div>
        <div class="blood-donation-details-panel"><a href="blood-donation-location.php">Location Available</a></div>
      </nav>
      <div class="date-drop-down-list">
        <h>Select date:</h>
        <div class="drop_down">
          <select id="date" name="Date" onchange="selectDate()">
            <option value="all">--- Select All ---</option>
            <?php
            $sql = "SELECT DISTINCT date FROM location_schedule ORDER BY date ASC"; 
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result)){
            ?>
              <option value="<?php echo $rows['date']; ?>"><?php echo $rows['date']; ?></option>
            <?php
            }
            ?>
          </select>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <?php
            $sql2 = "SELECT location_schedule.schedule_ID, location_schedule.location_name,
            hospital.location_type, hospital.state, location_schedule.date, location_schedule.time 
            FROM location_schedule INNER JOIN hospital 
            ON location_schedule.location_name = hospital.location_name
            ORDER BY location_schedule.date ASC";
            $result2 = $conn->query($sql2);
          ?>
          <div class = "table-header">
            <thead>
              <th style="width: 360px">Location Name</th>
              <th style="width: 200px">Location Type</th>
              <th style="width: 200px">State</th>
              <th style="width: 200px">Date</th>
              <th style="width: 200px">Time</th>
            </thead>
          </div>
          <tbody id="schedule_data">
            <?php
            if ($result2->num_rows > 0) {
              // output data of each row
              while($row2 = $result2->fetch_assoc()) {
            ?>
                <tr>
                  <td><?php echo $row2["location_name"]; ?></td>
                  <td><?php echo $row2["location_type"]; ?></td>
                  <td><?php echo $row2["state"]; ?></td>
                  <td><?php echo $row2["date"]; ?></td>
                  <td><?php echo $row2["time"]; ?></td>
                </tr>
        <?php }
            }else {
              echo "0 results";
            }
            $conn->close(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>