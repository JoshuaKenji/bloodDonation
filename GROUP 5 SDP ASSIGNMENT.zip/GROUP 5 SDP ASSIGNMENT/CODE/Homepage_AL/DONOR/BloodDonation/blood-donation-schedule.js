function selectDate(){
  var x = document.getElementById("date").value;

  $.ajax({
    url: "filter-date.php",
    method: "POST",
    data:{
      id : x
    },
    success: function(data){
      $("#schedule_data").html(data);
    }
  });
}