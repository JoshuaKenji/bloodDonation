<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = mysqli_connect("localhost", "root", "", "user_db");

$selected_state = $_POST['id'];
$selected_state = trim($selected_state);
if ($selected_state != "all"){
  $sql = "SELECT * FROM hospital WHERE state='{$selected_state}'";
  $result = mysqli_query($conn, $sql);
  while ($rows = mysqli_fetch_array($result)){
  ?>  <tr>
        <td><?php echo $rows['location_name']; ?></td>
        <td><?php echo $rows['location_type']; ?></td>
        <td><?php echo $rows['address']; ?></td>
        <td><?php echo $rows['state']; ?></td>
      </tr>
  <?php 
  }
}else{
  $sql2 = "SELECT * FROM hospital";
  $result2 = mysqli_query($conn,$sql2);
  while ($rows2 = mysqli_fetch_array($result2)){
  ?>  <tr>
        <td><?php echo $rows2['location_name']; ?></td>
        <td><?php echo $rows2['location_type']; ?></td>
        <td><?php echo $rows2['address']; ?></td>
        <td><?php echo $rows2['state']; ?></td>
      </tr>
  <?php
  }
} ?>
