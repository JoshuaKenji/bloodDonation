function selectState(){
  var x = document.getElementById("state").value;

  $.ajax({
    url: "filter-location.php",
    method: "POST",
    data:{
      id : x
    },
    success: function(data){
      $("#state_data").html(data);
    }
  });
}

