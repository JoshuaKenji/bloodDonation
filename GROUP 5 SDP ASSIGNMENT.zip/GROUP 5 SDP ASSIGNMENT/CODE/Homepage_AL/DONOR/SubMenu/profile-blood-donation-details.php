<?php
@include "../config.php";

session_start();

if(!isset($_SESSION['Donor_Username'])){
    header("location:../../../LoginPage/login_page.php");
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - BDH</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="profile-blood-donation-details.css">
  </head>
  <body>
    <header class="header">
      <div class="header-title">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../../icons/logout-icon.png">
        </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
          <div class="personal-information-panel"><a href="profile-personal-information.php">Personal Information</a></div>
          <div class="blood-donation-details-panel"><a>Blood Donation History</a></div>
      </nav>
      <div class="blood-donation-details-section">
        <!-- <img class="background-picture" src="../../../ImageAssets/blood-donation-background.jpg"> -->
        <?php
        $donor_name = $_SESSION['Donor_Username'];
        $sql = "SELECT User_ID from user_form WHERE Username='$donor_name'";
        $result = $conn->query($sql);
        if ($result -> num_rows >0){
          while($row = $result -> fetch_assoc()){
            $userID = $row["User_ID"];
          }
        }// retrieving donorID from $result, and store it in $userID
        $sql2 = "SELECT DISTINCT schedule_ID,location_name,location_type,date,time 
        FROM blood_donation WHERE user_id='$userID'";
        $result2 = $conn->query($sql2); //storing blood donation schedule with signed-up userID
        ?>
        <table class="table">
            <thead>
              <th>Location Name</th>
              <th>Location Type</th>
              <th>Date</th>
              <th>Time</th>
            </thead>
            <tbody>
              <?php
              if ($result2->num_rows > 0) {
                // output data of each row
                while($row2 = $result2->fetch_assoc()) {
              ?>
                  <tr>
                    <td><?php echo $row2["location_name"]; ?></td>
                    <td><?php echo $row2["location_type"]; ?></td>
                    <td><?php echo $row2["date"]; ?></td>
                    <td><?php echo $row2["time"]; ?></td>
                  </tr>
          <?php }
              }else {
                echo "0 results";
              }
              $conn->close(); ?>
            </tbody>
        </table>
      </div>
    </div>
  </body>
</html>