<?php

@include "config.php";

session_start();

if(!isset($_SESSION['Recipient_Username'])){
    header("location:../../LoginPage/login_page.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Blood Transfusion</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="blood-donation-location.css">
    <link rel="stylesheet" href="SubMenu-RP/profile-blood-donation-details.css">
  </head>
  <body>
    <header class="header">
      <div class="header-profile">Red Heart</div>
      <div class="log-out"><a href="home_page_AL-RP.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../icons/logout-icon.png">
          </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
        <div class="personal-information-panel"><a href="blood-donation-schedule.php">Blood Transfusion Schedule</a></div>
        <div class="blood-donation-details-panel"><a href="#">Location Available</a></div>
      </nav>
      <div class="state-drop-down-list">
        <h>Select your state:</h>
        <div class="drop_down">
          <select  id="state" name="State">
            <option value="0" hidden>All</option>
            <option value="1">Johor</option>
            <option value="2">Kedah</option>
            <option value="3">Kelantan</option> 
            <option value="4">Malacca</option>
            <option value="5">Negeri Sembilan</option>
            <option value="6">Pahang</option>
            <option value="7">Penang</option>
            <option value="8">Perak</option>
            <option value="9">Perlis</option>
            <option value="10">Selangor</option>
            <option value="11">Terengganu</option>
            <option value="12">Kuala Lumpur</option>
            <option value="13">Putra Jaya</option>
          </select>
        </div>
      </div>
      <div class="location-table">
        <div class="location-table-title">
          <div>Location Name</div>
          <div>Location Type</div>
          <div>Address</div>
          <div>State</div>
        </div>
        <div class="location-table-content">
          <div></div>
        </div>
      </div>
    </div>
  </body>
</html>