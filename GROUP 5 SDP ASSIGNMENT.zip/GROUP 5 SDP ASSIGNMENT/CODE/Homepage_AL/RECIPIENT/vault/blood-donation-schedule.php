<?php

@include "config.php";

session_start();

if(!isset($_SESSION['Recipient_Username'])){
    header("location:../../LoginPage/login_page.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Blood Transfusion</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="blood-donation.css"> -->
    <link rel="stylesheet" href="SubMenu-RP/profile-personal-information.css">
  </head>
  <body>
    <header class="header">
      <div class="header-profile">Red Heart</div>
      <div class="log-out"><a href="home_page_AL-RP.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../icons/logout-icon.png">
          </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
        <div class="personal-information-panel"><a href="#">Blood Transfusion Schedule</a></div>
        <div class="blood-donation-details-panel"><a href="blood-donation-location.php">Location Available</a></div>
      </nav>
  </body>
</html>