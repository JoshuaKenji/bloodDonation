<?php
@include "../config.php";

session_start();

if(!isset($_SESSION['Recipient_Username'])){
    header("location:../../../LoginPage/login_page.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Red Heart - Blood Transfusion</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script type="text/javascript" src="blood-donation-location.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="blood-donation-location.css">
    <link rel="stylesheet" href="profile-blood-donation-details.css">
  </head>
  <body>
    <header class="header">
      <div class="header-profile">Red Heart</div>
      <div class="log-out"><a href="../home_page_AL-RP.php">
          <div class="log-out-text">BACK</div>
          <img class="log-out-icon" src="../../../icons/logout-icon.png">
          </a>
      </div>
    </header>
    <div class="main-body">
      <nav class="top-bar">
        <div class="personal-information-panel"><a href="blood-donation-schedule.php">Blood Transfusion Schedule</a></div>
        <div class="blood-donation-details-panel"><a href="#">Location Available</a></div>
      </nav>
      <div class="state-drop-down-list">
        <h>Select state:</h>
        <div class="drop_down">
          <select id="state" name="State" onchange="selectState()">
            <option value="all">--- Select All ---</option>
            <?php
            $sql = "SELECT DISTINCT state FROM hospital"; 
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result)){
            ?>
              <option value="<?php echo $rows['state']; ?>"><?php echo $rows['state']; ?></option>
            <?php
            }
            ?>
          </select>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <?php
          $sql2 = "SELECT * FROM hospital";
          $result2 = mysqli_query($conn, $sql2);
          ?>
          <div class = "table-header">
            <thead>
              <th style="width: 300px">Location Name</th>
              <th style="width: 160px">Location Type</th>
              <th style="width: 530px">Address</th>
              <th style="width: 170px">State</th>
            </thead>
          </div>
          <tbody id="state_data">
            <?php
            if ($result2->num_rows > 0) {
              // output data of each row
              while($row2 = $result2->fetch_assoc()) {
            ?>
                <tr>
                  <td><?php echo $row2["location_name"]; ?></td>
                  <td><?php echo $row2["location_type"]; ?></td>
                  <td><?php echo $row2["address"]; ?></td>
                  <td><?php echo $row2["state"]; ?></td>
                </tr>
        <?php }
            }else {
              echo "0 results";
            }
            $conn->close(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>