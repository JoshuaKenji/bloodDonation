<?php

@include "../config.php";

session_start();

if(!isset($_SESSION['Recipient_Username'])){
    header("location:../../../LoginPage/login_page.php");
}

//foreign key
$userID = $_SESSION['Recipient_UserID'];
//--
$sql = "SELECT * FROM user_form WHERE User_ID = '$userID' ";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Red Heart - Profile</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="profile-personal-information.css">
    </head>
    <body>
        <header class="header">
            <div class="header-profile">Red Heart</div>
            <div class="log-out"><a href="../home_page_AL-RP.php">
                <div class="log-out-text">BACK</div>
                <img class="log-out-icon" src="../../../icons/logout-icon.png">
                </a>
            </div>
        </header>
        <div class="main-body">
            <nav class="top-bar">
                <div class="personal-information-panel"><a>Personal Information</a></div>
                <!-- <div class="blood-donation-details-panel"><a href="profile-blood-donation-details.php">Blood Donation History</a></div> -->
            </nav>
            <div class="personal-information-section">
                <div class="personal-information-content">
                    <div class="upper-column">
                        <div class="user-information-column1">
                            <div class="information-title">UserID:</div>
                            <div class="information-title">Full Name:</div>
                            <div class="information-title">Username:</div>
                            <div class="information-title">IC Number:</div>
                            <div class="information-title">Date of Birth:</div>
                        </div>
                        <div class="user-information-column2">
                            <div class="userID"><?php echo $row['User_ID']?></div>
                            <div class="full-name"><?php echo $row['Full_Name']?></div>
                            <div class="username"><?php echo $row['Username']?></div>
                            <div class="ic-number"><?php echo $row['IC_No']?></div>
                            <div class="dob"><?php echo $row['Birthday']?></div>
                        </div>
                        <div class="user-information-column3">
                            <div class="information-title">Gender:</div>
                            <div class="information-title">Blood Type:</div>
                            <div class="information-title">State:</div>
                            <div class="information-title">Status:</div>
                        </div>
                        <div class="user-information-column4">
                            <div class="gender"><?php echo $row['Gender']?></div>
                            <div class="blood-type"><?php echo $row['Blood_Type']?></div>
                            <div class="state"><?php echo $row['State']?></div>
                            <div class="state"><?php echo $row['User_Type']?></div>
                        </div>
                    </div>
                    <div class="lower-column">
                        <div class="past-medical-history-title">Past Medical History</div>
                        <div class="disease-content">
                            <div class="disease-title-list">
                                <div class="state"><?php echo $row['Past_Medical_History']?></div>
                            </div>
                        </div>                      
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

