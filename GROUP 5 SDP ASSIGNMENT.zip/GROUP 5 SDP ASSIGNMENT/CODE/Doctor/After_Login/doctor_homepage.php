<?php

@include "../../config.php";

session_start();

if(!isset($_SESSION['Doctor_Username'])){
    header("location:../login_page-D.php");
}

//foreign key
$userID = $_SESSION['Doctor_ID'];
//--
$sql = "SELECT * FROM doctor WHERE D_id = '$userID' ";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

?>

<!-- ------------------ -->

<!DOCTYPE html>
<html lang="en">

  <head>
    <title>Doctor's Home Page</title>
    <link rel="stylesheet" href="doctor_homepage.css"/>
  </head>
  
  <body>
    <div class="main" id="home">

        <div class="navbar">
            <div class="icon">
                <h2 class="logo"><a href="doctor_homepage.php" style="color: #00a2ff;text-shadow: 0.5px 0.5px 1px #000000;">Red Heart</a></h2>
            </div>

            <div class="menu">                    
                <ul>
                    <li><a href="cruds_sc_manage/read.php">Schedule Management</a></li>
                    <li><a href="report/report_user.php">User Report</a></li>
                    <!-- <li><a href="report/report_recipient.php">Recipient Report</a></li> -->
                    <li><a href="report/report_bloodBank.php">Blood Bank Report</a></li>
                    <li><a href="report/report_bloodDonation.php">Blood Donation Report</a></li>
                </ul>
            </div>
            <div class="login-user-section">
              <div><a class="login-user-tab" href="#">
                <div class="login-username"><?php echo $row['Username'] ?></div>
                <img class="drop-down-icon" src="../../icons/down-arrow-button.png"></a>
              </div>
              <div class="login-sub-menu">
                <div class="profile-tab"><a href="SubMenu/doctor_profile.php">Profile</a></div>
                <div class="sign-out-tab"><a href="../../SignOut.php">Sign Out</a></div>
              </div>
            </div>
            
        </div>

        <div class="home">

            <h1>Hello <span style="color:#00a2ff; text-transform:capitalize;"><?php echo $row['doctor_name'] ?></span></h1>

            <p class="par1">Thank you for contributing.<br>We are so thankful for your contribution in Red Heart, a volunteer-based organization that<br>helps the blood donation around West Malaysia. We hope that your service<br>brings benefit to West Malaysia and you can enjoy your service with us.<br>Once again, thank you for supporting!</p>

        </div>
    </div>

  </body>
</html>
