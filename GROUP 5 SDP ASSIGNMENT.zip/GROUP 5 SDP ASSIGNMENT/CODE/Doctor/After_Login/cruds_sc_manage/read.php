<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor - Manage Schedule</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="style.css" >
</head>


<body style ="margin:50px;" >
    <?php

    session_start();

    include('db.php');
    $query="SELECT * FROM location_schedule;";
    $result= mysqli_query($conn, $query);

    //user safety login
    if(!isset($_SESSION['Doctor_Username'])){
        header("location:../../login_page-D.php");
    }
    

    ?>

    <div class="container-my-5">
        <h1>Schedule Management</h1>
        <a class="btn btn-primary" role="button" href= "create.php" style="margin-top:15px;margin-bottom:20px;">New Schedule </a>
        <br>
        <table class='table'>
            <tr>
                <th>Schedule ID</th>
                <th>Location name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            <?php
                $i=0;
                while($row=mysqli_fetch_array($result))
                {
            ?>
                <tr>
                    <td><?php echo $row['schedule_id'] ?></td>
                    <td><?php echo $row['location_name'] ?></td>
                    <td><?php echo $row['date'] ?></td>
                    <td><?php echo $row['time'] ?></td>
                    <td><a href="update.php?schedule_id=<?php echo $row["schedule_id"]; ?>">Update</a></td>
                    <td><a href="delete.php?schedule_id=<?php echo $row["schedule_id"]; ?>"><span style="color:red"><u><i>Delete</i></u></a></td>
                </tr>
            <?php
            $i++;
                }
            ?>
        </table>

        <div class="col-sm-3-d-grid" role="button" >
            <a class="btn btn-outline-primary" href="../doctor_homepage.php">BACK</a>
        </div>
    </div>
</body>