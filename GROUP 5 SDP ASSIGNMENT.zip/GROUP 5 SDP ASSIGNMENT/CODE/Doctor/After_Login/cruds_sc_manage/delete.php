<?php
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $db = "user_db";

  $conn = mysqli_connect($hostname, $username, $password, $db);

  $sql = "DELETE FROM location_schedule WHERE schedule_id='" . $_GET["schedule_id"] . "'";
  
  if (mysqli_query($conn, $sql)) {
      echo "<script LANGUAGE='JavaScript'>
      window.alert('Delete Success');
      window.location.href='read.php';
      </script>";
  } else {
      echo "Error deleting record: " . mysqli_error($conn);
  }
  mysqli_close($conn);
?>