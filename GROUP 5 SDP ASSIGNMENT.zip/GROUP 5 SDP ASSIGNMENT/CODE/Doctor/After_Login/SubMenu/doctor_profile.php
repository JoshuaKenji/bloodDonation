<?php

@include "../../config.php";

session_start();

if(!isset($_SESSION['Doctor_Username'])){
    header("location:../login_page-D.php");
}


//foreign key
$userID = $_SESSION['Doctor_ID'];
//--
$sql = "SELECT * FROM doctor WHERE D_id = '$userID' ";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Red Heart - Profile</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="doctor_profile.css">
    </head>
    <body>
        <header class="header">
            <div class="header-profile">Red Heart</div>
            <div class="log-out"><a href="../doctor_homepage.php">
                <div class="log-out-text">BACK</div>
                <img class="log-out-icon" src="../../../icons/logout-icon.png">
                </a>
            </div>
        </header>
        <div class="main-body">

            <nav class="top-bar">
                <div class="personal-information-panel"><a>Personal Information</a></div>
                <!-- <div class="blood-donation-details-panel"><a href="profile-blood-donation-details.php">Blood Donation History</a></div> -->
            </nav>

            <div class="personal-information-section">
                <div class="personal-information-content">
                    <div class="upper-column">
                        <div class="user-information-column1">
                            <div class="information-title">Doctor ID:</div>
                            <div class="information-title">Full Name:</div>
                            <div class="information-title">Username:</div>
                            <div class="information-title">Specialism:</div>
                            <div class="information-title">Certificate Code:</div>
                        </div>

                        <div class="user-information-column2">
                            <div class="userID"><?php echo $row['D_id']?></div>
                            <div class="full-name"><?php echo $row['doctor_name']?></div> 
                            <div class="username"><?php echo $row['Username']?></div>
                            <div class="ic-number"><?php echo $row['specialism']?></div>
                            <div class="dob"><?php echo $row['certification']?></div>
                        </div>
                    </div>

                    <!-- <div class="lower-column">
                        <div class="past-medical-history-title">Past Medical History</div>
                        <div class="disease-content">
                            <div class="disease-title-list">
                                <div class="state">x</div>
                            </div>
                        </div>                      
                    </div> -->

                </div>
            </div>
        </div>
    </body>
</html>
