<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard - Blood Donation</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
      body{
        font-family: "Poppins", sans-serif;
        background-color: #A7BBCB;
      }
      .button{
        background-color: #008CBA;
        /* Blue */
        border-radius: 10px;
        border: none;
        padding: 15px 32px;
        text-align: center;
        display: inline-block;
        font-size: 16px;
        margin-right: 10px;
        cursor: pointer;
        box-shadow: 0.5px 0.5px 2px grey;
      }
      .button a{
        text-decoration: none;
        font-weight: bold;
        color: white;
      }
      .charts-group{
        display:flex;
        align-items: center;
        background-color: rgba(255,255,255, 0.4);
        border-radius: 20px;
      }
      .charts-group-right{
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      .charts-group div{
        margin: 0px 40px;
      }
    </style>
  </head>

  <body>
    <div style="display: flex; justify-content: space-between; align-items: center">
      <h1 style="padding: 0 40px">Graphical Dashboard - Blood Donation</h1>
      <button class="button"><a href="report_bloodDonation.php">BACK</a></button>
    </div>
    <?php
    $con = new mysqli('localhost','root','','user_db');

    $query = $con->query("
      SELECT COUNT(blood_donation.user_id) AS NumberOfDonorsByGender, user_form.Gender FROM
      blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID
      GROUP BY Gender;
    ");
    foreach($query as $data)
    {
      $gender[] = $data['Gender'];
      $usersAmountByGender[] = $data['NumberOfDonorsByGender'];
    }

    $query2 = $con->query("
      SELECT COUNT(blood_donation_id) AS NumberOfDonationByDate, date FROM blood_donation
      GROUP BY date;
    ");
    foreach($query2 as $data)
    {
      $date[] = $data['date'];
      $donationNumberByDate[] = $data['NumberOfDonationByDate'];
    }

    $query3 = $con->query("
      SELECT COUNT(blood_donation.blood_donation_id) AS NumberOfDonationByState, hospital.state 
      FROM blood_donation INNER JOIN hospital ON blood_donation.location_name = hospital.location_name 
      GROUP BY state;
    ");
    foreach($query3 as $data)
    {
      $state[] = $data['state'];
      $donationNumberByState[] = $data['NumberOfDonationByState'];
    }

    $query4 = $con->query("
    SELECT COUNT(blood_donation.user_id) AS NumberOfDonors, user_form.Blood_Type 
    FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
    GROUP BY Blood_Type;
    ");
    foreach($query4 as $data)
    {
      $bloodType[] = $data['Blood_Type'];
      $donorsAmount[] = $data['NumberOfDonors'];
    }
    ?>

    <div class="charts-group">
      <div style="width: 400px; display: flex; align-items: center; flex-direction: column">
        <h2>Number of Donors by Gender</h2>
        <canvas id="gender"></canvas>
      </div>
      <div class="charts-group-right">
        <div style="width: 500px; display: flex; align-items: center; flex-direction: column">
          <h2>Numbers of Donors by Date</h2>
          <canvas id="date"></canvas>
        </div>
        <div style="width: 500px; display: flex; align-items: center; flex-direction: column">
          <h2>Number of Donors by Blood Type</h2>
          <canvas id="bloodType"></canvas>
        </div>
      </div>
      <div style="width: 400px; display: flex; align-items: center; flex-direction: column">
        <h2>Number of Donors by state</h2>
        <canvas id="state"></canvas>
      </div>
    </div>

    <script>
      const labels = <?php echo json_encode($gender) ?>;
      const data = {
        labels: labels,
        datasets: [{
          label: 'Number of donors',
          data: <?php echo json_encode($usersAmountByGender) ?>,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)'
          ],
          hoverOffset: 4
        }]
      };
    
      const config = {
        type: 'doughnut',
        data: data,
      };

      const gender = new Chart(
        document.getElementById('gender'),
        config
      );
    </script>

    <script>
      const labels2 = <?php echo json_encode($date) ?>;
      const data2 = {
        labels: labels2,
        datasets: [{
          label: 'Number of Donors',
          data: <?php echo json_encode($donationNumberByDate) ?>,
          borderColor: [
            'rgb(255, 99, 132)',
          ],
          tension: 0.4
        }]
      };
    
      const config2 = {
        type: 'line',
        data: data2,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        },
      };

      const date = new Chart(
        document.getElementById('date'),
        config2
      );
    </script>

    <script>
      const labels3 = <?php echo json_encode($bloodType) ?>;
      const data3 = {
        labels: labels3,
        datasets: [{
          label: 'Number of Donors',
          data: <?php echo json_encode($donorsAmount) ?>,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderWidth: 1
        }]
      };
    
      const config3 = {
        type: 'bar',
        data: data3,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        },
      };

      const bloodType = new Chart(
        document.getElementById('bloodType'),
        config3
      );
    </script>

    <script>
      const labels4 = <?php echo json_encode($state) ?>;
      const data4 = {
        labels: labels4,
        datasets: [{
          label: 'Number of users',
          data: <?php echo json_encode($donationNumberByState) ?>,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)'
          ],
          hoverOffset: 4
        }]
      };
    
      const config4 = {
        type: 'doughnut',
        data: data4,
      };

      const state = new Chart(
        document.getElementById('state'),
        config4
      );
    </script>
  </body>
</html>