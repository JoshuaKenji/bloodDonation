<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation Report</title>
</head>

<body>
    <!DOCTYPE html>
    <html>

    <head>
        <style>
            
            /* me add */

            @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@700&family=Poppins:wght@400;500;600&display=swap');

            body{
                font-family: "Poppins", sans-serif;
                height: 100vh;
                background-color: #A7BBCB;
                background-position: center;
                background-size: cover;
            }

            h1{
                color: white;
                margin-bottom: 10px;
                font-size: 50px;
                text-shadow: .7px .7px 2px black;
            }

            table {
                color: #3e567c;
                border-collapse: collapse;
                width: 100%;
                /* text-shadow: .7px .7px 2px grey; */
                /* box-shadow: 0.5px 0.5px 2px grey; */
            }

            td,
            th {
                border: 1px solid #dddddd;
                text-align: center;
                padding: 8px;
            }

            tr:nth-child(even) {
                background-color: #C0C0C0;
            }

            td {
                text-align: center;
            }

            .button {
                background-color: #008CBA;
                /* Blue */
                border-radius: 10px;
                border: none;
                color: white;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 18px;
                margin: 4px 2px;
                margin-top: 0px;
                /* margin-bottom: 20px; */
                cursor: pointer;
                box-shadow: 0.5px 0.5px 2px grey;
            }

            .container.my-5 a{
                text-decoration:none;
                color: white;
            }

            .print {
                @page :footer {
                    display: none
                }

                @page :header {
                    display: none
                }
            }
        </style>
    </head>

    <body>

        <?php
        include_once('db.php');

        //verify session n user

        session_start();

        if(!isset($_SESSION['Doctor_Username'])){
            header("location:../../login_page-D.php");
        }

        $query = "SELECT blood_donation.blood_donation_id, blood_donation.user_id, user_form.Blood_Type, blood_donation.date
                  FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID";
        $result = mysqli_query($conn, $query);
        ?>
        <div class="container my-5">
            <h1> &#128137 Blood Bank Report</h1>
            <button class="button"><a href="bloodBank_report_pdf.php" target="_blank">Generate Report</a></button>
            <button class="button"><a href="bloodBank_report_dashboard.php">Graphical Dashboard</a></button>
            <button class="button" role="button"><a href="../doctor_homepage.php">Back</a></button>
            <p style="font-size: 15px; margin-left: 10px">*  Generate report for further information</p>
            <!-- <script> function printpage() {
            //Get the print button and put it into a variable
            var printButton = document.getElementById("printpagebutton");
            //Set the print button visibility to 'hidden'
            printButton.style.visibility = 'hidden';
            //Print the page content
            window.print()
            printButton.style.visibility = 'visible';
            } -->
            <!-- </script> -->
            <table class='table'>
                <tr>
                    <th>Blood ID</th>
                    <th>Blood Group</th>
                    <th>Blood Donated Date</th>
                    <th>Expiry Date</th>
                </tr>
                <?php
                $i = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['Blood_Type']; ?></td>
                        <td><?php echo $row['date']; ?></td>
                        <?php
                        $date = $row['date']; 
                        ?>
                        <td><?php echo date('Y-m-d', strtotime($date. '+ 35 days'));?></td>
                        <?php $i = $i + 1;?>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>


    </body>

    </html>