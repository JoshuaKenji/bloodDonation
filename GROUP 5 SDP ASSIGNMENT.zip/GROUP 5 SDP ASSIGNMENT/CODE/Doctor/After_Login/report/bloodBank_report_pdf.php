<?php
require_once 'dompdf/vendor/autoload.php';
session_start();

if(!isset($_SESSION['Doctor_Username'])){
    header("location:../login_page-D.php");
}
//foreign key
$userID = $_SESSION['Doctor_ID'];

use Dompdf\Dompdf;

$conn = new PDO ('mysql: host=localhost;dbname=user_db','root','');

//foreign key
$userID = $_SESSION['Doctor_ID'];
//--

$sql4 = "SELECT * FROM doctor WHERE D_id = '$userID' ";

$stmt4 = $conn->prepare($sql4);
$stmt4->execute();
$rows4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);

$sql = 'SELECT blood_donation.blood_donation_id, blood_donation.user_id, user_form.Blood_Type, blood_donation.date
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID';
$stmt = $conn->prepare($sql);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql2 = "SELECT COUNT(blood_donation_id) AS A_plus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'A +'";
$stmt2 = $conn->prepare($sql2);
$stmt2->execute();
$rows2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);

$sql3 = "SELECT COUNT(blood_donation_id) AS A_minus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'A -'";
$stmt3 = $conn->prepare($sql3);
$stmt3->execute();
$rows3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);

$sql5 = "SELECT COUNT(blood_donation_id) AS B_plus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'B +'";
$stmt5 = $conn->prepare($sql5);
$stmt5->execute();
$rows5 = $stmt5->fetchAll(PDO::FETCH_ASSOC);

$sql6 = "SELECT COUNT(blood_donation_id) AS B_minus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'B -'";
$stmt6 = $conn->prepare($sql6);
$stmt6->execute();
$rows6 = $stmt6->fetchAll(PDO::FETCH_ASSOC);

$sql7 = "SELECT COUNT(blood_donation_id) AS O_plus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'O +'";
$stmt7 = $conn->prepare($sql7);
$stmt7->execute();
$rows7 = $stmt7->fetchAll(PDO::FETCH_ASSOC);

$sql8 = "SELECT COUNT(blood_donation_id) AS O_minus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'O -'";
$stmt8 = $conn->prepare($sql8);
$stmt8->execute();
$rows8 = $stmt8->fetchAll(PDO::FETCH_ASSOC);

$sql9 = "SELECT COUNT(blood_donation_id) AS AB_plus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'AB +'";
$stmt9 = $conn->prepare($sql9);
$stmt9->execute();
$rows9 = $stmt9->fetchAll(PDO::FETCH_ASSOC);

$sql10 = "SELECT COUNT(blood_donation_id) AS AB_minus, user_form.Blood_Type 
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID 
WHERE Blood_Type = 'AB -'";
$stmt10 = $conn->prepare($sql10);
$stmt10->execute();
$rows10 = $stmt10->fetchAll(PDO::FETCH_ASSOC);

$totalDonor = 0;

$i = 1;

$html = '<!DOCTYPE html>
<html>
  <head>
    <title>Blood Bank Report</title>
    <style>
      .top-banner{
        top:0;
        height: 10px;
        background-color:red;
      }
      h2{
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-align: left;
        color: red;
      }
      .doctor-info{
        display:flex;
        padding-top: 20px;
        padding-bottom: 20px;
      }
      .info-title,
      .info-data,
      .report-date{
        display: inline-block;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        padding-right: 20px;
      }
      .info-title{
        font-weight: bold;
      }
      table{
        font-family: Arial;
        border-collapse: collapse;
        width: 100%;
      }
      td,th{
        font-family: "Poppins", sans-serif;
        border: 1px solid #444;
        padding: 8px;
        text-align: left;
        font-size: 12px;
      }
      thead th{
        background-color: pink;
      }
      .my-table{
        text-align: right;
        background-color: pink;
      }
      #sign{
        padding-top: 50px;
        text-align: right;
      }
    </style>
  </head>
  <body>
    <div class="top-banner"></div>
    <h2 style="color: rgb(124, 14, 14)">RED HEART</h2>
    <h2>Blood Bank Report</h2>
    <div class="doctor-info">
      <div class="info-title">
        <div>Doctor ID:</div>
        <div>Doctor Name:</div>
        <div>Specialism:</div>
        <div>Certification Code:</div>
      </div>
      <div class="info-data">';
      foreach ($rows4 as $row4){
        $html .= '
        <div>'.$row4['D_id'].'</div>
        <div>'.$row4['doctor_name'].'</div>
        <div>'.$row4['specialism'].'</div>
        <div>'.$row4['certification'].'</div>';
      };
      $html .=' 
      </div>
      <div style="padding-left: 200px; padding-right: 0" class="report-date">
        <div style="display: inline-block; font-weight: bold">Date:</div>
        <div style="display: inline-block">'.date("Y-m-d").'</div>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th colspan="8" style="background-color: red"></th>
        </tr>
        <tr>
          <th colspan="2">Blood ID</th>
          <th colspan="2">Blood Group</th>
          <th colspan="2">Blood Donated Date</th>
          <th colspan="2">Blood Expiry Date</th>
        </tr>
      </thead>
      <tbody>
        ';

      foreach($rows as $row){
        $html .= '<tr>
        <td colspan="2">'.$i.'</td>
        <td colspan="2">'.$row['Blood_Type'].'</td>
        <td colspan="2">'.$row['date'].'</td>
        <td colspan="2">'.date('Y-m-d', strtotime($row['date']. '+ 35 days')).'</td>
      </tr>';
      $i++;
      };
      $html .= '</tbody>
    </table>
    <p style="font-family: Verdana, Geneva, Tahoma, sans-serif; font-weight: bold; 
    ">*  Amount of blood donated at a time consists of 450ml</p>
    <table>
      <tr>
        <th colspan="8" style="background-color: red; color: white">
          Total Amount of Blood in each Blood Group (millilitre)
        </th>
      </tr>
      <tr>
        <th colspan="1" class="my-table">A +</th>';
        foreach ($rows2 as $row2){
          $html .= '<th>'.number_format($row2['A_plus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">A -</th>';
        foreach ($rows3 as $row3){
          $html .= '<th>'.number_format($row3['A_minus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">B +</th>';
        foreach ($rows5 as $row5){
          $html .= '<th>'.number_format($row5['B_plus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">B -</th>';
        foreach ($rows6 as $row6){
          $html .= '<th>'.number_format($row6['B_minus'] * 450).'</th>';
        }
        ;
      $html .= '
      </tr>
      <tr>
        <th colspan="1" class="my-table">O +</th>';
        foreach ($rows7 as $row7){
          $html .= '<th>'.number_format($row7['O_plus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">O -</th>';
        foreach ($rows8 as $row8){
          $html .= '<th>'.number_format($row8['O_minus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">AB +</th>';
        foreach ($rows9 as $row9){
          $html .= '<th>'.number_format($row9['AB_plus'] * 450).'</th>';
        }
        ;
        $html .='
        <th colspan="1" class="my-table">AB -</th>';
        foreach ($rows10 as $row10){
          $html .= '<th>'.number_format($row10['AB_minus'] * 450).'</th>';
        }
        ;
      $html .= '
      </tr>
      <tr>
        <td colspan="8" id="sign">Signature</td>
      </tr>
    </table>
  </body>
</html>';

$dompdf = new Dompdf();
$dompdf -> loadHtml($html);
$dompdf -> setPaper('A4','portrait');
$dompdf -> render();
$dompdf -> stream('user_report.pdf',['Attachment' => 0]);
?>