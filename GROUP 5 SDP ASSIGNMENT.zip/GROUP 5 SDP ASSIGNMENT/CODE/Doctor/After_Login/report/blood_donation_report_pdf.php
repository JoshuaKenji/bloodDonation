<?php
require_once 'dompdf/vendor/autoload.php';
session_start();

if(!isset($_SESSION['Doctor_Username'])){
    header("location:../login_page-D.php");
}
//foreign key
$userID = $_SESSION['Doctor_ID'];

use Dompdf\Dompdf;

$conn = new PDO ('mysql: host=localhost;dbname=user_db','root','');

//foreign key
$userID = $_SESSION['Doctor_ID'];
//--
$sql4 = "SELECT * FROM doctor WHERE D_id = '$userID' ";

$stmt4 = $conn->prepare($sql4);
$stmt4->execute();
$rows4 = $stmt4->fetchAll(PDO::FETCH_ASSOC);

$sql = 'SELECT blood_donation.blood_donation_id, blood_donation.user_id, user_form.Gender, 
user_form.Blood_Type, blood_donation.location_name, hospital.state, blood_donation.date
FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID
INNER JOIN hospital ON blood_donation.location_name = hospital.location_name';

$stmt = $conn->prepare($sql);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql2 = "SELECT COUNT(blood_donation.user_id) AS TotalMaleDonor FROM blood_donation INNER JOIN user_form
        ON blood_donation.user_id = user_form.User_ID
        WHERE user_form.Gender = 'Male'";
$stmt2 = $conn->prepare($sql2);
$stmt2->execute();
$rows2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);

$sql3 = "SELECT COUNT(blood_donation.user_id) AS TotalFemaleDonor FROM blood_donation INNER JOIN user_form
        ON blood_donation.user_id = user_form.User_ID
        WHERE user_form.Gender = 'Female';";
$stmt3 = $conn->prepare($sql3);
$stmt3->execute();
$rows3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);

$totalDonor = 0;

$html = '<!DOCTYPE html>
<html>
  <head>
    <title>Blood Donation Report</title>
    <style>
      .top-banner{
        top:0;
        height: 10px;
        background-color:red;
      }
      h2{
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-align: left;
        color: red;
      }
      .doctor-info{
        display:flex;
        padding-top: 20px;
        padding-bottom: 20px;
      }
      .info-title,
      .info-data,
      .report-date{
        display: inline-block;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        padding-right: 20px;
      }
      .info-title{
        font-weight: bold;
      }
      table{
        font-family: Arial;
        border-collapse: collapse;
        width: 100%;
      }
      td,th{
        font-family: "Poppins", sans-serif;
        border: 1px solid #444;
        padding: 8px;
        text-align: left;
        font-size: 12px;
      }
      thead th{
        background-color: pink;
      }
      .my-table{
        text-align: right;
        background-color: pink;
      }
      #sign{
        padding-top: 50px;
        text-align: right;
      }
    </style>
  </head>
  <body>
    <div class="top-banner"></div>
    <h2 style="color: rgb(124, 14, 14)">RED HEART</h2>
    <h2>Blood Donation Report</h2>
    <div class="doctor-info">
      <div class="info-title">
        <div>Doctor ID:</div>
        <div>Doctor Name:</div>
        <div>Specialism:</div>
        <div>Certification Code:</div>
      </div>
      <div class="info-data">';
      foreach ($rows4 as $row4){
        $html .= '
        <div>'.$row4['D_id'].'</div>
        <div>'.$row4['doctor_name'].'</div>
        <div>'.$row4['specialism'].'</div>
        <div>'.$row4['certification'].'</div>';
      };
      $html .=' 
      </div>
      <div style="padding-left: 200px; padding-right: 0" class="report-date">
        <div style="display: inline-block; font-weight: bold">Date:</div>
        <div style="display: inline-block">'.date("Y-m-d").'</div>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th style="width: 10%">Blood Donation ID</th>
          <th style="width: 5%">Donor ID</th>
          <th style="width: 5%">Gender</th>
          <th style="width: 5%">Blood Type</th>
          <th style="width: 30%">Location Name</th>
          <th style="width: 15%">State</th>
          <th style="width: 15%">date</th>
        </tr>
      </thead>
      <tbody>
        ';

      foreach($rows as $row){
        $html .= '<tr>
        <td>'.$row['blood_donation_id'].'</td>
        <td>'.$row['user_id'].'</td>
        <td>'.$row['Gender'].'</td>
        <td>'.$row['Blood_Type'].'</td>
        <td>'.$row['location_name'].'</td>
        <td>'.$row['state'].'</td>
        <td>'.$row['date'].'</td>
      </tr>';
      };
      $html .= '</tbody>
      <tr>
        <th colspan="6" class="my-table">Male Donor:</th>';
        foreach ($rows2 as $row2){
          $html .= '<th>'.$row2['TotalMaleDonor'].'</th>';
          $totalDonor += number_format($row2['TotalMaleDonor']);
        };
      $html .= '
      </tr>
      <tr>
        <th colspan="6" class="my-table">Female Donor:</th>';
        foreach ($rows3 as $row3){
          $html .= '<th>'.$row3['TotalFemaleDonor'].'</th>';
          $totalDonor += number_format($row3['TotalFemaleDonor']);
        };
      $html .= '
      </tr>
      <tr>
        <th colspan="6" class="my-table">Total Donation:</th>
        <th>'.$totalDonor.'</th>
      </tr>
      <tr>
        <td colspan="7" id="sign">Signature</td>
      </tr>
    </table>
  </body>
</html>';

$dompdf = new Dompdf();
$dompdf -> loadHtml($html);
$dompdf -> setPaper('A4','portrait');
$dompdf -> render();
$dompdf -> stream('blood_donation_report.pdf',['Attachment' => 0]);
?>