<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard - Blood Bank</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
      body{
        font-family: "Poppins", sans-serif;
        background-color: #A7BBCB;
      }
      .button{
        background-color: #008CBA;
        /* Blue */
        border-radius: 10px;
        border: none;
        padding: 15px 32px;
        text-align: center;
        display: inline-block;
        font-size: 16px;
        margin-right: 10px;
        cursor: pointer;
        box-shadow: 0.5px 0.5px 2px grey;
      }
      .button a{
        text-decoration: none;
        font-weight: bold;
        color: white;
      }
    </style>
  </head>
  <body>
  <div style="display: flex; justify-content: space-between; align-items: center">
      <h1 style="padding: 0 40px">Graphical Dashboard - Blood Bank</h1>
      <button class="button"><a href="report_bloodBank.php">BACK</a></button>
    </div>
    <?php
    $con = new mysqli('localhost','root','','user_db');
    $query = $con->query("
      SELECT COUNT(blood_donation.user_id) AS NumberOfUsersByBlood, user_form.Blood_Type 
      FROM blood_donation INNER JOIN user_form ON blood_donation.user_id = user_form.User_ID
      GROUP BY Blood_Type;
    ");
    foreach($query as $data)
    {
      $bloodType[] = $data['Blood_Type'];
      $usersAmountByBlood[] = $data['NumberOfUsersByBlood'];
    }
    ?>
    <div style="display: flex; justify-content: center">
      <div style="width: 1000px; display: flex; align-items: center; flex-direction: column; 
      background-color: rgba(255,255,255,0.4); padding: 50px; border-radius: 10px">
        <div>Blood Packs per Blood Type</div>
        <canvas id="bloodType"></canvas>
      </div>
    </div>
    <script>
      const labels = <?php echo json_encode($bloodType) ?>;
      const data = {
        labels: labels,
        datasets: [{
          label: 'Number of Blood Packs',
          data: <?php echo json_encode($usersAmountByBlood) ?>,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderWidth: 1
        }]
      };
    
      const config = {
        type: 'bar',
        data: data,
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        },
      };

      const bloodType = new Chart(
        document.getElementById('bloodType'),
        config
      );
    </script>
  </body>
</html>