<?php
@include "config.php";

session_start();

if (isset($_POST["submit"])){

  $Username = mysqli_real_escape_string($conn, $_POST["Username"]);
  $Password = $_POST["Password"];

  $select = " SELECT * FROM `doctor` WHERE Username = '$Username' && Password = '$Password' ";

  $result = mysqli_query($conn, $select);

  if(mysqli_num_rows($result) > 0){
    
    $row = mysqli_fetch_array($result);

    $_SESSION['Doctor_Username'] = $row["Username"];
    //primary key
    $_SESSION['Doctor_ID'] = $row["D_id"];
    //--
    header('location:After_Login/doctor_homepage.php');

    // $row = mysqli_fetch_array($result);

    // if('Username' == "admin"){
    //   header('location:../Admin/admin_homepage.html');
    // }else{  
    //   header('location:../home_page.php');
    // }  

    // if($row['User_Type'] == "admin"){

    //   $_SESSION['Admin_Username'] = $row["Username"];
    //   header('location:../home_page.php');

    // }elseif($row['User_Type'] == "doctor"){
      
    //   $_SESSION['Doctor_Username'] = $row["Username"];
    //   header('location:../home_page.php');
    // }
    
  }else{
    // echo"<script>alert('Incorrect username or password!');</script>";
    $error[] = "incorrect username or password!";
  }

};
?>

<!-- --------------------------------------------------------------------- -->

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Read Heart - Doctor's Login Page</title>
        <link rel="stylesheet" href="login_page_style.css">
    </head>

    <body>

      <div class="top">
        <button class="back"><a href="../home_page.html">BACK</a></button>
      </div>

      <div class="center">
        <h1>Doctor's Login</h1>
        <form action="" method="post">

        <!-- php connection -->
        <?php
        if(isset($error)){
          foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
          };
        };
        ?>

          <div class="txt_field">
            <input type="text" name="Username" required>
            <!-- <input type="text" name="Username" required placeholder=""> -->
            <span></span>
            <label>Username</label>
          </div>
          <div class="txt_field">
            <input type="password" name="Password" required>
            <span></span>
            <label>Password</label>
          </div>

          <input class="button" name="submit" type="submit" value="Login">

        </form>
      </div>

    </body>
</html>