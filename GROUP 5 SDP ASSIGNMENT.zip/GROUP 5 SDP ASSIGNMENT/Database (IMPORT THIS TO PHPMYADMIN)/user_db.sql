-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 04, 2022 at 08:22 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `blood_donation`
--

DROP TABLE IF EXISTS `blood_donation`;
CREATE TABLE IF NOT EXISTS `blood_donation` (
  `blood_donation_id` int(3) NOT NULL AUTO_INCREMENT,
  `schedule_id` int(3) NOT NULL,
  `user_id` int(3) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `location_type` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`blood_donation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_donation`
--

INSERT INTO `blood_donation` (`blood_donation_id`, `schedule_id`, `user_id`, `location_name`, `location_type`, `date`, `time`) VALUES
(8, 1, 9, 'Hospital Rehabilitasi Cheras', 'Hospital', '2022-08-01', '08.00 - 12.00'),
(14, 2, 14, 'Kuala Lumpur Hospital', 'Hospital', '2022-08-01', '09.00 - 13.00'),
(15, 6, 8, 'Hospital Jelebu', 'Hospital', '2022-08-05', '08.00 - 12.00'),
(10, 5, 12, 'Tuanku Jaafar Hospital', 'Hospital', '2022-08-04', '10.30 - 17.30'),
(16, 2, 13, 'Kuala Lumpur Hospital', 'Hospital', '2022-08-01', '09.00 - 13.00'),
(17, 3, 5, 'National Heart Institute of Malaysia ', 'Institute', '2022-08-03', '08.30 - 12.30'),
(18, 2, 18, 'Kuala Lumpur Hospital', 'Hospital', '2022-08-01', '09.00 - 13.00'),
(19, 5, 5, 'Tuanku Jaafar Hospital', 'Hospital', '2022-08-04', '10.30 - 17.30'),
(20, 10, 5, 'Gleneagles Hospital', 'Hospital', '2022-08-06', '08.00 - 16.00');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `D_id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `doctor_name` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `specialism` varchar(50) NOT NULL,
  `certification` varchar(50) NOT NULL,
  PRIMARY KEY (`D_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`D_id`, `Username`, `doctor_name`, `Password`, `specialism`, `certification`) VALUES
(1, 'MilaHelv', 'Dr. Mila Helveston', '123', 'Whole Blood Donation', 'NPS'),
(2, 'MariaRx', 'Dr. Maria Rorex', '123', 'Platelet Donation', 'PTC-AAH'),
(3, 'CCambero', 'Dr. Carol Cambero', '123', 'Whole Blood Donation', 'CBT-ACA'),
(4, 'ValDo', 'Dr. Valerie Doxey', '123', 'Power Red Donation', 'PTC-AMCA'),
(5, 'Anas.111', 'Dr. Anastasia Alfisi', '123', 'Plasma Donation', 'PBT-ASCP'),
(6, 'MayaSim', 'Dr. Maya Simatupang', '123', 'Platelet Donation', 'CPT-NHA'),
(7, 'JamFre', ' Dr. Jamie Frens', '123', 'Whole Blood Donation', 'CPT-NPA'),
(8, 'DonMol', 'Dr. Donovan Mollberg', '123', 'Whole Blood Donation', 'PTC-AMCA'),
(9, 'MKK123', 'Dr. McKenna Kindregan', '123', 'Plasma Donation', 'RPT-AMT'),
(10, 'drguacamole', 'Dr. Essie Guadalupe', '123', 'Platelet Donation', 'PTC-ASPT');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
CREATE TABLE IF NOT EXISTS `hospital` (
  `H_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(50) NOT NULL,
  `location_type` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  PRIMARY KEY (`H_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`H_id`, `location_name`, `location_type`, `address`, `state`) VALUES
(1, 'Hospital Rehabilitasi Cheras', 'Hospital', 'Jalan Yaacob Latif, Bandar Tun Razak, 56000 Cheras', 'Kuala Lumpur'),
(2, 'Tuanku Jaafar Hospital', 'Hospital', 'Jalan Rasah, Bukit Rasah, 70300 Seremban\r\n', 'Negeri Sembilan'),
(3, 'Kuala Lumpur Hospital', 'Hospital', 'Jalan Pahang, 50586', 'Kuala Lumpur'),
(4, 'Hospital Bentong', 'Hospital', 'Jalan Padang, 28700 Bentong', 'Pahang'),
(5, 'National Heart Institute of Malaysia', 'Institute', '145, Jln Tun Razak, 50400', 'Kuala Lumpur'),
(6, 'Malacca General Hospital', 'Hospital', 'Jalan Mufti Haji Khalil, 75400 ', 'Melaka'),
(7, 'Camp Rasah', 'Camp', 'Bukit Rasah, 70300 Seremban', 'Negeri Sembilan'),
(8, 'Blood Donation Camp Kuala Lumpur', 'Camp', 'Jln Tun Razak, Titiwangsa, 50400', 'Kuala Lumpur'),
(9, 'Gleneagles hospital', 'Hospital', 'Block A & Block B, 286 & 288, Jln Ampang, Kampung Berembang, 50450 ', 'Kuala Lumpur'),
(10, 'Hospital Jelebu', 'Hospital', 'Jln Kuala Klawang - Titi, Taman Bukit Petaling, 71600 Kuala Klawang', 'Negeri Sembilan');

-- --------------------------------------------------------

--
-- Table structure for table `location_schedule`
--

DROP TABLE IF EXISTS `location_schedule`;
CREATE TABLE IF NOT EXISTS `location_schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(50) NOT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`schedule_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location_schedule`
--

INSERT INTO `location_schedule` (`schedule_id`, `location_name`, `date`, `time`) VALUES
(1, 'Hospital Rehabilitasi Cheras', '2022-08-01', '08.00 - 12.00'),
(2, 'Kuala Lumpur Hospital', '2022-08-01', '09.00 - 13.00'),
(3, 'National Heart Institute of Malaysia ', '2022-08-03', '08.30 - 12.30'),
(4, 'Malacca General Hospital', '2022-08-04', '09.00 - 15.00'),
(5, 'Tuanku Jaafar Hospital', '2022-08-04', '10.30 - 17.30'),
(6, 'Hospital Jelebu', '2022-08-05', '08.00 - 12.00'),
(7, 'Hospital Bentong', '2022-08-05', '09.00 - 13.00'),
(8, 'Camp Rasah', '2022-08-12', '08.30 - 15.30'),
(9, 'Blood Donation Camp Kuala Lumpur ', '2022-08-13', '09.30 - 14.30'),
(10, 'Gleneagles Hospital', '2022-08-06', '08.00 - 16.00');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

DROP TABLE IF EXISTS `user_form`;
CREATE TABLE IF NOT EXISTS `user_form` (
  `User_ID` int(255) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Full_Name` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `IC_No` int(11) NOT NULL,
  `Birthday` date NOT NULL,
  `Gender` enum('Male','Female') NOT NULL,
  `Blood_Type` enum('A','A +','A -','B','B +','B -','O','O +','O -','AB','AB +','AB -') NOT NULL,
  `Past_Medical_History` varchar(255) NOT NULL,
  `State` enum('Johor','Kedah','Kelantan','Malacca','Negeri Sembilan','Pahang','Penang','Perak','Perlis','Selangor','Terengganu','Kuala Lumpur','Putra Jaya') NOT NULL,
  `User_Type` enum('Donor','Recipient') NOT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`User_ID`, `Username`, `Full_Name`, `Password`, `IC_No`, `Birthday`, `Gender`, `Blood_Type`, `Past_Medical_History`, `State`, `User_Type`) VALUES
(3, 'joshua.kenji', 'Joshua Kenji Istitoro', '202cb962ac59075b964b07152d234b70', 105042004, '2004-04-05', 'Male', 'A +', 'Lactose Intolerance', 'Kuala Lumpur', 'Recipient'),
(5, 'miss.maan7', 'Sanjeet Kaur Fatimahi', '202cb962ac59075b964b07152d234b70', 209032002, '2002-03-09', 'Female', 'AB +', 'Tourretes', 'Negeri Sembilan', 'Donor'),
(14, 'DankNullNate', 'Ahmed Naheyan Chowdhury', '202cb962ac59075b964b07152d234b70', 123091999, '1999-11-23', 'Male', 'B +', 'Deuteranomaly (Color Blind)', 'Perak', 'Donor'),
(7, 'VigneshRaja', 'Vignesh Sanjaya', '202cb962ac59075b964b07152d234b70', 2211102, '2002-11-21', 'Male', 'O -', 'Autism', 'Kuala Lumpur', 'Recipient'),
(8, 'Royce.Adams', 'Royce Adams', '202cb962ac59075b964b07152d234b70', 119032001, '2001-03-19', 'Male', 'AB +', 'Alcoholism', 'Kuala Lumpur', 'Recipient'),
(12, 'jun.yee', 'Tin Jun Yee', '202cb962ac59075b964b07152d234b70', 202062002, '2002-06-02', 'Male', 'A +', 'Scoliosis', 'Johor', 'Recipient'),
(13, 'HubertCS', 'Hubert Chang Sanjaya', '202cb962ac59075b964b07152d234b70', 204072004, '2004-07-04', 'Male', 'O +', 'Dwarfism', 'Perlis', 'Recipient'),
(15, 'GraceCCY', 'Grace Chong Chi Yen', '202cb962ac59075b964b07152d234b70', 130072002, '2002-07-30', 'Female', 'O +', 'PTSD', 'Selangor', 'Donor'),
(16, 'ZiSheng', 'Won Zi Sheng', '202cb962ac59075b964b07152d234b70', 123102002, '2002-10-23', 'Male', 'A +', 'Gaming Addiction', 'Kuala Lumpur', 'Donor'),
(17, 'Uncle.Mutu', 'Raditya Mutu Sancaya', '202cb962ac59075b964b07152d234b70', 121091984, '1984-09-21', 'Male', 'AB +', 'Diabetes', 'Penang', 'Donor'),
(18, 'yuliyuli', 'Yulius Richard Edwin Chan', '202cb962ac59075b964b07152d234b70', 106052003, '2003-05-06', 'Male', 'O +', 'Obesity', 'Kuala Lumpur', 'Donor'),
(19, 'LooDickLeng', 'Loo Dick Leng', '202cb962ac59075b964b07152d234b70', 127122001, '2001-12-27', 'Male', 'AB -', 'Addiction', 'Selangor', 'Donor');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
